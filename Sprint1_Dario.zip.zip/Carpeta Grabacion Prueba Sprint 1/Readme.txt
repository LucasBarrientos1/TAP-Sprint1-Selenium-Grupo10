01
Instalar Python y Selenium
Primero aseguraste que Python estuviera instalado y luego agregaste Selenium con pip.

En la terminal: pip install selenium

Verificaste que Python estaba disponible con python --version

Ejecutaste pip install selenium

Ignoraste advertencias sobre PATH porque no afectan el uso de Selenium

02
Configurar Edge WebDriver
Edge necesita su propio driver para que Selenium pueda controlarlo.

Descargar msedgedriver.exe desde la página oficial de Microsoft Edge WebDriver

Descargaste la versión que coincide con tu navegador Edge

Guardaste el archivo en una carpeta accesible

Agregaste esa carpeta al PATH o la dejaste junto al script

03
Crear script de prueba en Python
Escribiste un archivo simple para abrir Edge y cargar una página.

Archivo test_edge.py

python
from selenium import webdriver

# Usar Edge
options = webdriver.EdgeOptions()
driver = webdriver.Edge(options=options)

# Abrir Google
driver.get("https://www.google.com")
print(driver.title)

# Cerrar navegador
driver.quit()

04
Ejecutar y verificar
Corriste el script para comprobar que Selenium controla Edge correctamente.

En la terminal: python test_edge.py

Se abrió una ventana de Edge

Entró a Google automáticamente

Mostró el título de la página en la consola

Cerró el navegador al final